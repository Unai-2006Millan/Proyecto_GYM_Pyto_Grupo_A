
public abstract class Usuario {
	 private String dni;
	 private String nombre;
	 private String apellido;
	 private String telefono;
	 private String email;
	 private String contrasena;

	 public abstract boolean iniciarSesion(String dni, String pass);
	 public abstract void cerrarSesion();
}
