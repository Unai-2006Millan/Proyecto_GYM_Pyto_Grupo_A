public class Recepcionista extends Trabajador {
public class Pago {
}
public class ActividadProgramada {
}
public class Nomina {
}

    public void registrarPago(Pago p) {
    }

    public boolean programarActividad(ActividadProgramada a) {
        return false;
    }

    @Override
    public Nomina generarNomina() {
        return null;
    }
}