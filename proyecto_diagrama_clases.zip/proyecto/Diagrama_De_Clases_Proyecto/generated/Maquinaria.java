import java.util.Date;

public class Maquinaria {

    private String tipo;
    private String marca;
    private String numSerie;
    private Date fechaCompra;
    private Date fechaUltMantenimiento;
    private String estado;

    public boolean necesitaMantenimiento() {
        return false;
    }

    public int diasParaMantenimiento() {
        return 0;
    }
}
