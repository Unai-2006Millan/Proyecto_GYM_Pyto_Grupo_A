import java.util.Date;

public class Socio extends Usuario {
public class ActividadProgramada {
}
public class Reserva {
}

    private Date fechaAlta;
    private String estado;
    private String tipoPlan;

    public boolean reservarActividad(ActividadProgramada a) {
        return false;
    }

    public boolean cancelarReserva(Reserva r) {
        return false;
    }

    public void pagarCuota() {
    }

    public boolean esMoroso() {
        return false;
    }

    @Override
    public boolean iniciarSesion(String dni, String pass) {
        return false;
    }

    @Override
    public void cerrarSesion() {
    }
}