import java.util.Date;

public class Pago {

    private Date fecha;
    private double importe;
    private String tipoPago;
}