import java.time.LocalDateTime;

public class Sala {

    private String nombre;
    private double metros;
    private int aforo;

    public boolean esDisponible(LocalDateTime inicio, LocalDateTime fin) {
        return false;
    }
}