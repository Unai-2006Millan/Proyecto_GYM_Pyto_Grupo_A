
public class Actividad {

    private String nombre;
    private String descripcion;
    private String nivel;
}