public class Administrador extends Trabajador {
public class Entrenador {
}
public class Sala {
}
public class Maquinaria {
}
public class Nomina {
}

    public void registrarSocio(Socio s) {
    }

    public boolean eliminarSocio(Socio s) {
        return false;
    }

    public void registrarEntrenador(Entrenador e) {
    }

    public void registrarSala(Sala s) {
    }

    public void registrarMaquina(Maquinaria m) {
    }

    @Override
    public Nomina generarNomina() {
        return null;
    }
}