
public class Nomina {

    private String mes;
    private double salarioCalculado;
}