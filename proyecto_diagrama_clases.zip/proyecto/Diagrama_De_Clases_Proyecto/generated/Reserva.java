
public class Reserva {

    public boolean cancelar() {
        return false;
    }
}