import java.util.Date;

public abstract class Trabajador extends Usuario {
public class Nomina {
}

    private Date fechaAlta;
    private String estado;

    public abstract Nomina generarNomina();

    @Override
    public boolean iniciarSesion(String dni, String pass) {
        return false;
    }

    @Override
    public void cerrarSesion() {
    }
}