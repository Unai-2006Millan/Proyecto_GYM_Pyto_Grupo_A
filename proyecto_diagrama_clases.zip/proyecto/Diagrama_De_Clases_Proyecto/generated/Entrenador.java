import java.util.List;

public class Entrenador extends Trabajador {
public class ActividadProgramada {
}
public class Nomina {
}

    private String tipoContrato;

    public List<ActividadProgramada> verPlanificacionSemanal() {
        return null;
    }

    public List<ActividadProgramada> verPlanificacionMensual() {
        return null;
    }

    @Override
    public Nomina generarNomina() {
        return null;
    }
}