import java.time.LocalDateTime;

public class ActividadProgramada {

    private LocalDateTime fechaInicio;
    private LocalDateTime fechaFin;

    public boolean verificarDisponibilidad() {
        return false;
    }
}