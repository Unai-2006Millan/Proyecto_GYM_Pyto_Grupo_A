package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import Clases.Entrenador;
import Controlador.GestionEntrenador;
import Controlador.GestionInicioSesion;

import java.sql.SQLException;

public class EntrenadorTest {

    // PARTICIONES DE EQUIVALENCIA

    @Test
    public void PE017_InsertarEntrenadorValido() {
        Entrenador e = new Entrenador(
                "12345678A",
                "Juan",
                "Perez",
                "600111222",
                "juan@mail.com",
                "1234",
                "2026-01-01",
                "TC",
                "activo",
                1500.0
        );

        assertDoesNotThrow(() -> {
            GestionEntrenador.insertarEntrenador(e);
        });
    }

    @Test
    public void PE018_EmailInvalido() {
        Entrenador e = new Entrenador(
                "12345678A",
                "Juan",
                "Perez",
                "600111222",
                "juanmail.com",
                "1234",
                "2026-01-01",
                "TC",
                "activo",
                1500.0
        );

        assertThrows(IllegalArgumentException.class, () -> {
            GestionEntrenador.insertarEntrenador(e);
        });
    }

    @Test
    public void PE019_ModificarCamposVacios() {
        Entrenador e = new Entrenador(
                "12345678A",
                "",
                "Perez",
                "600111222",
                "juan@mail.com",
                "1234",
                "2026-01-01",
                "TC",
                "activo",
                1500.0
        );

        assertThrows(IllegalArgumentException.class, () -> {
            GestionEntrenador.modificarEntrenador(e);
        });
    }

    @Test
    public void PE020_EliminarEntrenador() {
        assertDoesNotThrow(() -> {
            GestionEntrenador.eliminarEntrenador("12345678A");
        });
    }

    @Test
    public void PE021_SeleccionarNoExiste() throws SQLException {
        Entrenador e = GestionEntrenador.seleccionarEntrenador("00000000Z");

        assertNull(e);
    }

    @Test
    public void PE022_LoginValido() throws SQLException {
        String[] r = GestionInicioSesion.consultaInicio("juan@mail.com", "1234");

        assertNotNull(r);
    }

    @Test
    public void PE023_LoginIncorrecto() throws SQLException {
        String[] r = GestionInicioSesion.consultaInicio("error@mail.com", "wrong");

        assertNull(r);
    }

    @Test
    public void PE024_EstadoInvalido() {
        Entrenador e = new Entrenador(
                "12345678A",
                "Juan",
                "Perez",
                "600111222",
                "juan@mail.com",
                "1234",
                "2026-01-01",
                "TC",
                "xxx",
                1500.0
        );

        assertThrows(IllegalArgumentException.class, () -> {
            GestionEntrenador.modificarEntrenador(e);
        });
    }

    // VALORES LÍMITE

    @Test
    public void VL018_DniVacio() {
        Entrenador e = new Entrenador(
                "",
                "Juan",
                "Perez",
                "600111222",
                "juan@mail.com",
                "1234",
                "2026-01-01",
                "TC",
                "activo",
                1500.0
        );

        assertThrows(IllegalArgumentException.class, () -> {
            GestionEntrenador.insertarEntrenador(e);
        });
    }

    @Test
    public void VL019_DniMaximo() {
        Entrenador e = new Entrenador(
                "123456789012345",
                "Juan",
                "Perez",
                "600111222",
                "juan@mail.com",
                "1234",
                "2026-01-01",
                "TC",
                "activo",
                1500.0
        );

        assertDoesNotThrow(() -> {
            GestionEntrenador.insertarEntrenador(e);
        });
    }

    @Test
    public void VL020_EmailSinArroba() {
        Entrenador e = new Entrenador(
                "12345678A",
                "Juan",
                "Perez",
                "600111222",
                "juanmail.com",
                "1234",
                "2026-01-01",
                "TC",
                "activo",
                1500.0
        );

        assertThrows(IllegalArgumentException.class, () -> {
            GestionEntrenador.insertarEntrenador(e);
        });
    }

    @Test
    public void VL021_TelefonoVacio() {
        Entrenador e = new Entrenador(
                "12345678A",
                "Juan",
                "Perez",
                "",
                "juan@mail.com",
                "1234",
                "2026-01-01",
                "TC",
                "activo",
                1500.0
        );

        assertThrows(IllegalArgumentException.class, () -> {
            GestionEntrenador.insertarEntrenador(e);
        });
    }

    @Test
    public void VL022_ContraseñaVacia() {
        Entrenador e = new Entrenador(
                "12345678A",
                "Juan",
                "Perez",
                "600111222",
                "juan@mail.com",
                "",
                "2026-01-01",
                "TC",
                "activo",
                1500.0
        );

        assertThrows(IllegalArgumentException.class, () -> {
            GestionEntrenador.insertarEntrenador(e);
        });
    }

    @Test
    public void VL023_PlanValido() {
        Entrenador e = new Entrenador(
                "12345678A",
                "Juan",
                "Perez",
                "600111222",
                "juan@mail.com",
                "1234",
                "2026-01-01",
                "FULL",
                "activo",
                1500.0
        );

        assertDoesNotThrow(() -> {
            GestionEntrenador.insertarEntrenador(e);
        });
    }

    @Test
    public void VL024_EstadoInvalido() {
        Entrenador e = new Entrenador(
                "12345678A",
                "Juan",
                "Perez",
                "600111222",
                "juan@mail.com",
                "1234",
                "2026-01-01",
                "TC",
                "xxx",
                1500.0
        );

        assertThrows(IllegalArgumentException.class, () -> {
            GestionEntrenador.insertarEntrenador(e);
        });
    }

    @Test
    public void VL025_FechaNull() {
        Entrenador e = new Entrenador(
                "12345678A",
                "Juan",
                "Perez",
                "600111222",
                "juan@mail.com",
                "1234",
                null,
                "TC",
                "activo",
                1500.0
        );

        assertThrows(IllegalArgumentException.class, () -> {
            GestionEntrenador.insertarEntrenador(e);
        });
    }

    @Test
    public void VL026_SalarioNull() {
    	Double salario = null;

        Entrenador e = new Entrenador(
                "12345678A",
                "Juan",
                "Perez",
                "600111222",
                "juan@mail.com",
                "1234",
                "2026-01-01",
                "TC",
                "activo",
                salario
        );

        assertThrows(IllegalArgumentException.class, () -> {
            GestionEntrenador.insertarEntrenador(e);
        });
    }

    // CONJETURA DE ERRORES

    @Test
    public void CE016_DniDuplicado() {
        Entrenador e = new Entrenador(
                "11111111A",
                "Juan",
                "Perez",
                "600111222",
                "juan@mail.com",
                "1234",
                "2026-01-01",
                "TC",
                "activo",
                1500.0
        );

        assertThrows(SQLException.class, () -> {
            GestionEntrenador.insertarEntrenador(e);
        });
    }

    @Test
    public void CE017_SQLNull() {
        assertThrows(SQLException.class, () -> {
            GestionEntrenador.insertarEntrenador(null);
        });
    }

    @Test
    public void CE018_ModificarNoExiste() {
        Entrenador e = new Entrenador(
                "00000000Z",
                "Juan",
                "Perez",
                "600111222",
                "juan@mail.com",
                "1234",
                "2026-01-01",
                "TC",
                "activo",
                1500.0
        );

        assertDoesNotThrow(() -> {
            GestionEntrenador.modificarEntrenador(e);
        });
    }

    @Test
    public void CE019_LoginPasswordIncorrecta() throws SQLException {
        String[] r = GestionInicioSesion.consultaInicio("juan@mail.com", "wrong");

        assertNull(r);
    }

    @Test
    public void CE020_InsertarSalarioInvalido() {
        assertThrows(Exception.class, () -> {
            GestionEntrenador.insertarEntrenador(null);
        });
    }

    @Test
    public void CE021_UpdateEstadoNull() {
        Entrenador e = new Entrenador(
                "12345678A",
                "Juan",
                "Perez",
                "600111222",
                "juan@mail.com",
                "1234",
                "2026-01-01",
                null,
                "activo",
                1500.0
        );

        assertThrows(IllegalArgumentException.class, () -> {
            GestionEntrenador.modificarEntrenador(e);
        });
    }

    @Test
    public void CE022_ListarBDCaida() {
        assertThrows(SQLException.class, () -> {
            GestionEntrenador.listarEntrenador();
        });
    }
}