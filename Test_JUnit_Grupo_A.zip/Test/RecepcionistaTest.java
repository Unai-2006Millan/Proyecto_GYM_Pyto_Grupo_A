package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import Clases.Recepcionista;
import Controlador.GestionInicioSesion;
import Controlador.GestionRecepcionista;

import java.sql.SQLException;

public class RecepcionistaTest {

    // PARTICIONES DE EQUIVALENCIA

    @Test
    public void PE009_InsertarRecepcionistaValido() {
        Recepcionista r = new Recepcionista(
                "12345678A",
                "Ana",
                "Lopez",
                "600111222",
                "ana@mail.com",
                "1234",
                "2026-01-01",
                "TC",
                "activo",
                1200.0
        );

        assertDoesNotThrow(() -> {
            GestionRecepcionista.insertarRecepcionista(r);
        });
    }

    @Test
    public void PE010_EmailInvalido() {
        Recepcionista r = new Recepcionista(
                "12345678A",
                "Ana",
                "Lopez",
                "600111222",
                "anamail.com",
                "1234",
                "2026-01-01",
                "TC",
                "activo",
                1200.0
        );

        assertThrows(IllegalArgumentException.class, () -> {
            GestionRecepcionista.insertarRecepcionista(r);
        });
    }

    @Test
    public void PE011_ModificarCamposVacios() {
        Recepcionista r = new Recepcionista(
                "12345678A",
                "",
                "Lopez",
                "600111222",
                "ana@mail.com",
                "1234",
                "2026-01-01",
                "TC",
                "activo",
                1200.0
        );

        assertThrows(IllegalArgumentException.class, () -> {
            GestionRecepcionista.modificarRecepcionista(r);
        });
    }

    @Test
    public void PE012_EliminarRecepcionista() {
        assertDoesNotThrow(() -> {
            GestionRecepcionista.eliminarRecepcionista("12345678A");
        });
    }

    @Test
    public void PE013_SeleccionarNoExiste() throws SQLException {
        Recepcionista r = GestionRecepcionista.seleccionarRecepcionista("00000000Z");

        assertNull(r);
    }

    @Test
    public void PE014_LoginValido() throws SQLException {
        String[] r = GestionInicioSesion.consultaInicio("ana@mail.com", "1234");

        assertNotNull(r);
    }

    @Test
    public void PE015_LoginIncorrecto() throws SQLException {
        String[] r = GestionInicioSesion.consultaInicio("error@mail.com", "wrong");

        assertNull(r);
    }

    @Test
    public void PE016_EstadoInvalido() {
        Recepcionista r = new Recepcionista(
                "12345678A",
                "Ana",
                "Lopez",
                "600111222",
                "ana@mail.com",
                "1234",
                "2026-01-01",
                "TC",
                "xxx",
                1200.0
        );

        assertThrows(IllegalArgumentException.class, () -> {
            GestionRecepcionista.modificarRecepcionista(r);
        });
    }

    // VALORES LÍMITE

    @Test
    public void VL009_DniVacio() {
        Recepcionista r = new Recepcionista(
                "",
                "Ana",
                "Lopez",
                "600111222",
                "ana@mail.com",
                "1234",
                "2026-01-01",
                "TC",
                "activo",
                1200.0
        );

        assertThrows(IllegalArgumentException.class, () -> {
            GestionRecepcionista.insertarRecepcionista(r);
        });
    }

    @Test
    public void VL010_DniMaximo() {
        Recepcionista r = new Recepcionista(
                "123456789012345",
                "Ana",
                "Lopez",
                "600111222",
                "ana@mail.com",
                "1234",
                "2026-01-01",
                "TC",
                "activo",
                1200.0
        );

        assertDoesNotThrow(() -> {
            GestionRecepcionista.insertarRecepcionista(r);
        });
    }

    @Test
    public void VL011_EmailSinArroba() {
        Recepcionista r = new Recepcionista(
                "12345678A",
                "Ana",
                "Lopez",
                "600111222",
                "anamail.com",
                "1234",
                "2026-01-01",
                "TC",
                "activo",
                1200.0
        );

        assertThrows(IllegalArgumentException.class, () -> {
            GestionRecepcionista.insertarRecepcionista(r);
        });
    }

    @Test
    public void VL012_TelefonoVacio() {
        Recepcionista r = new Recepcionista(
                "12345678A",
                "Ana",
                "Lopez",
                "",
                "ana@mail.com",
                "1234",
                "2026-01-01",
                "TC",
                "activo",
                1200.0
        );

        assertThrows(IllegalArgumentException.class, () -> {
            GestionRecepcionista.insertarRecepcionista(r);
        });
    }

    @Test
    public void VL013_ContraseñaVacia() {
        Recepcionista r = new Recepcionista(
                "12345678A",
                "Ana",
                "Lopez",
                "600111222",
                "ana@mail.com",
                "",
                "2026-01-01",
                "TC",
                "activo",
                1200.0
        );

        assertThrows(IllegalArgumentException.class, () -> {
            GestionRecepcionista.insertarRecepcionista(r);
        });
    }

    @Test
    public void VL014_PlanValido() {
        Recepcionista r = new Recepcionista(
                "12345678A",
                "Ana",
                "Lopez",
                "600111222",
                "ana@mail.com",
                "1234",
                "2026-01-01",
                "FULL",
                "activo",
                1200.0
        );

        assertDoesNotThrow(() -> {
            GestionRecepcionista.insertarRecepcionista(r);
        });
    }

    @Test
    public void VL015_EstadoInvalido() {
        Recepcionista r = new Recepcionista(
                "12345678A",
                "Ana",
                "Lopez",
                "600111222",
                "ana@mail.com",
                "1234",
                "2026-01-01",
                "TC",
                "xxx",
                1200.0
        );

        assertThrows(IllegalArgumentException.class, () -> {
            GestionRecepcionista.insertarRecepcionista(r);
        });
    }

    @Test
    public void VL016_FechaNull() {
        Recepcionista r = new Recepcionista(
                "12345678A",
                "Ana",
                "Lopez",
                "600111222",
                "ana@mail.com",
                "1234",
                null,
                "TC",
                "activo",
                1200.0
        );

        assertThrows(IllegalArgumentException.class, () -> {
            GestionRecepcionista.insertarRecepcionista(r);
        });
    }

    @Test
    public void VL017_SalarioNull() {
    	
		Double salario = null;
    	
        @SuppressWarnings("null")
		Recepcionista r = new Recepcionista(
                "12345678A",
                "Ana",
                "Lopez",
                "600111222",
                "ana@mail.com",
                "1234",
                "2026-01-01",
                "TC",
                "activo",
                salario
        );

        assertThrows(IllegalArgumentException.class, () -> {
            GestionRecepcionista.insertarRecepcionista(r);
        });
    }

    // CONJETURA DE ERRORES

    @Test
    public void CE009_DniDuplicado() {
        Recepcionista r = new Recepcionista(
                "11111111A",
                "Ana",
                "Lopez",
                "600111222",
                "ana@mail.com",
                "1234",
                "2026-01-01",
                "TC",
                "activo",
                1200.0
        );

        assertThrows(SQLException.class, () -> {
            GestionRecepcionista.insertarRecepcionista(r);
        });
    }

    @Test
    public void CE010_SQLNull() {
        assertThrows(SQLException.class, () -> {
            GestionRecepcionista.insertarRecepcionista(null);
        });
    }

    @Test
    public void CE011_ModificarNoExiste() {
        Recepcionista r = new Recepcionista(
                "00000000Z",
                "Ana",
                "Lopez",
                "600111222",
                "ana@mail.com",
                "1234",
                "2026-01-01",
                "TC",
                "activo",
                1200.0
        );

        assertDoesNotThrow(() -> {
            GestionRecepcionista.modificarRecepcionista(r);
        });
    }

    @Test
    public void CE012_LoginPasswordIncorrecta() throws SQLException {
        String[] r = GestionInicioSesion.consultaInicio("ana@mail.com", "wrong");

        assertNull(r);
    }

    @Test
    public void CE013_SalarioInvalido() {
        assertThrows(Exception.class, () -> {
            GestionRecepcionista.insertarRecepcionista(null);
        });
    }

    @Test
    public void CE014_UpdateEstadoNull() {
        Recepcionista r = new Recepcionista(
                "12345678A",
                "Ana",
                "Lopez",
                "600111222",
                "ana@mail.com",
                "1234",
                "2026-01-01",
                null,
                "activo",
                1200.0
        );

        assertThrows(IllegalArgumentException.class, () -> {
            GestionRecepcionista.modificarRecepcionista(r);
        });
    }

    @Test
    public void CE015_ListarBDCaida() {
        assertThrows(SQLException.class, () -> {
            GestionRecepcionista.listarRecepcionistas();
        });
    }
}