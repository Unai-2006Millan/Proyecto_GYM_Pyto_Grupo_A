package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import Clases.Socio;
import Controlador.GestionInicioSesion;
import Controlador.GestionSocio;

import java.sql.SQLException;

public class SocioTest {

    // PARTICIONES DE EQUIVALENCIA

    @Test
    public void PE001_InsertarSocioValido() {
        Socio s = new Socio("12345678A", "Juan", "Perez", "600111222",
                "juan@mail.com", "1234", "2026-01-01", "FULL");

        assertDoesNotThrow(() -> {
            GestionSocio.insertarSocio(s);
        });
    }

    @Test
    public void PE002_EmailInvalido() {
        Socio s = new Socio("12345678A", "Juan", "Perez", "600111222",
                "juanmail.com", "1234", "2026-01-01", "FULL");

        assertThrows(IllegalArgumentException.class, () -> {
            GestionSocio.insertarSocio(s);
        });
    }

    @Test
    public void PE003_ModificarCamposVacios() {
        Socio s = new Socio("12345678A", "", "Perez", "600111222",
                "juan@mail.com", "1234", "2026-01-01", "FULL");

        assertThrows(IllegalArgumentException.class, () -> {
            GestionSocio.modificarSocio(s);
        });
    }

    @Test
    public void PE004_EliminarSocioExistente() {
        String dni = "12345678A";

        assertDoesNotThrow(() -> {
            GestionSocio.eliminarSocio(dni);
        });
    }

    @Test
    public void PE005_SeleccionarNoExiste() throws SQLException {
        Socio s = GestionSocio.seleccionarSocio("00000000Z");

        assertNull(s);
    }

    @Test
    public void PE006_LoginValido() throws SQLException {
        String[] s = GestionInicioSesion.consultaInicio("juan@mail.com", "1234");

        assertNotNull(s);
    }

    @Test
    public void PE007_LoginIncorrecto() throws SQLException {
        String[] s = GestionInicioSesion.consultaInicio("error@mail.com", "wrong");

        assertNull(s);
    }

    @Test
    public void PE008_EstadoInvalido() {
        Socio s = new Socio("12345678A", "Juan", "Perez", "600111222",
                "juan@mail.com", "1234", "2026-01-01", "FULL", "xxx");

        assertThrows(IllegalArgumentException.class, () -> {
            GestionSocio.modificarSocio(s);
        });
    }

    // VALORES LIMITE

    @Test
    public void VL001_DniVacio() {
        Socio s = new Socio("", "Juan", "Perez", "600111222",
                "juan@mail.com", "1234", "2026-01-01", "FULL");

        assertThrows(IllegalArgumentException.class, () -> {
            GestionSocio.insertarSocio(s);
        });
    }

    @Test
    public void VL002_DniMaximo() throws SQLException {
        Socio s = new Socio("123456789012345", "Juan", "Perez", "600111222",
                "juan@mail.com", "1234", "2026-01-01", "FULL");

        assertDoesNotThrow(() -> {
            GestionSocio.insertarSocio(s);
        });
    }

    @Test
    public void VL003_EmailSinArroba() {
        Socio s = new Socio("12345678A", "Juan", "Perez", "600111222",
                "juanmail.com", "1234", "2026-01-01", "FULL");

        assertThrows(IllegalArgumentException.class, () -> {
            GestionSocio.insertarSocio(s);
        });
    }

    @Test
    public void VL004_TelefonoVacio() {
        Socio s = new Socio("12345678A", "Juan", "Perez", "",
                "juan@mail.com", "1234", "2026-01-01", "FULL");

        assertThrows(IllegalArgumentException.class, () -> {
            GestionSocio.insertarSocio(s);
        });
    }

    @Test
    public void VL005_ContraseñaVacia() {
        Socio s = new Socio("12345678A", "Juan", "Perez", "600111222",
                "juan@mail.com", "", "2026-01-01", "FULL");

        assertThrows(IllegalArgumentException.class, () -> {
            GestionSocio.insertarSocio(s);
        });
    }

    @Test
    public void VL006_PlanValido() throws SQLException {
        Socio s = new Socio("12345678A", "Juan", "Perez", "600111222",
                "juan@mail.com", "1234", "2026-01-01", "FULL");

        assertDoesNotThrow(() -> {
            GestionSocio.insertarSocio(s);
        });
    }

    @Test
    public void VL007_EstadoInvalido() {
        Socio s = new Socio("12345678A", "Juan", "Perez", "600111222",
                "juan@mail.com", "1234", "2026-01-01", "xxx");

        assertThrows(IllegalArgumentException.class, () -> {
            GestionSocio.insertarSocio(s);
        });
    }

    @Test
    public void VL008_FechaNull() {
        Socio s = new Socio("12345678A", "Juan", "Perez", "600111222",
                "juan@mail.com", "1234", null, "FULL");

        assertThrows(IllegalArgumentException.class, () -> {
            GestionSocio.insertarSocio(s);
        });
    }

    // CONJETURA DE ERRORES

    @Test
    public void CE001_DniDuplicado() {
        Socio s = new Socio("11111111A", "Juan", "Perez", "600111222",
                "juan@mail.com", "1234", "2026-01-01", "FULL");

        assertThrows(SQLException.class, () -> {
            GestionSocio.insertarSocio(s);
        });
    }

    @Test
    public void CE002_SQLNull() {
        assertThrows(SQLException.class, () -> {
            GestionSocio.insertarSocio(null);
        });
    }

    @Test
    public void CE003_ModificarNoExiste() throws SQLException {
        Socio s = new Socio("00000000Z", "Juan", "Perez", "600111222",
                "juan@mail.com", "1234", "2026-01-01", "FULL");

        assertThrows(IllegalArgumentException.class, () -> {
            GestionSocio.modificarSocio(s);
        });
    }

    @Test
    public void CE004_EliminarConDependencias() {
        assertThrows(SQLException.class, () -> {
            GestionSocio.eliminarSocio("99999999A");
        });
    }

    @Test
    public void CE005_LoginPasswordIncorrecta() throws SQLException {
        String[] s = GestionInicioSesion.consultaInicio("juan@mail.com", "wrong");

        assertNull(s);
    }

    @Test
    public void CE006_SalarioInvalido() {
        assertThrows(Exception.class, () -> {
            GestionSocio.insertarSocio(null);
        });
    }

    @Test
    public void CE007_UpdateEstadoNull() {
        Socio s = new Socio("12345678A", "Juan", "Perez", "600111222",
                "juan@mail.com", "1234", "2026-01-01", null);

        assertThrows(IllegalArgumentException.class, () -> {
            GestionSocio.modificarSocio(s);
        });
    }

    @Test
    public void CE008_ListarBDCaida() {
        assertThrows(SQLException.class, () -> {
            GestionSocio.listarSocios();
        });
    }
}